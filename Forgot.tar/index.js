import {Component} from 'react'

import './index.css'

import {Link} from 'react-router-dom'

class Forgot extends Component {
  state = {
    name: '',
    password: '',
    newPassword: '',
  }

  onChangePassword = event => {
    this.setState({password: event.target.value})
  }

  onChangeUser = event => {
    this.setState({name: event.target.value})
  }

  onChangePassword2 = event => {
    this.setState({newPassword: event.target.value})
  }

  onSubmit = event => {
    event.preventDefault()
    const {name, password, newPassword} = this.state

    // const local = localStorage.setItem('name', name)
    // const pass = localStorage.setItem('password', password)
    // console.log(pass)
    // console.log(local)
    const storedName = localStorage.getItem('name')
    console.log(storedName)
  }

  render() {
    const {name, password, newPassword} = this.state
    return (
      <div className="forgot-container">
        <h1 className="heading">Forgot your Password?</h1>

        <form onSubmit={this.submitForm}>
          <div className="form-group">
            <div className="form-group">
              <label htmlFor="name" className="label3">
                name
              </label>

              <br />
              <input
                type="text"
                className="form-control3"
                value={name}
                id="name"
                onChange={this.onChangeUser}
                required
              />
            </div>
            <label htmlFor="password" className="label3">
              password
            </label>

            <br />
            <input
              type="password"
              className="form-control3"
              value={password}
              id="password"
              onChange={this.onChangePassword}
              required
            />
          </div>
          <br />
          <div className="form-group">
            <label htmlFor="newPassword" className="label3">
              Confirm Password
            </label>

            <br />
            <input
              type="password"
              className="form-control3"
              value={newPassword}
              id="newPassword"
              onChange={this.onChangePassword2}
              required
            />
          </div>
          <button type="submit" className="button">
            Reset Password
          </button>
          <Link to="/login">
            <p className="login">Login</p>
          </Link>
        </form>
      </div>
    )
  }
}
export default Forgot
