import React from 'react'

import {Link} from 'react-router-dom'

import './index.css'

const lowerCaseLetters = /[a-z]/g
const upperCaseLetters = /[A-Z]/g
const numbers = /[0-9]/g

class Register extends React.Component {
  state = {
    name: '',
    email: '',
    phone: '',
    password: '',
  }

  onChangeName = e => {
    this.setState({name: e.target.value})
  }

  onChangeEmail = e => {
    this.setState({email: e.target.value})
  }

  onChangePhone = e => {
    this.setState({phone: e.target.value})
  }

  onChangePassword = e => {
    this.setState({password: e.target.value})
  }

  onSubmit = e => {
    e.preventDefault()

    const {name, email, phone, password, err} = this.state
    const {history} = this.props

    if (name.length === 0) {
      //   alert('Please fill in email')
      this.setState({err: 'plase fill'})
      ;<p>fill this form</p>
    } else if (password.length === 0) {
      alert('Please fill in password')
    } else if (name.length === 0 && password.length === 0) {
      alert('Please fill in email and password')
    } else if (password.length > 8) {
      alert('Max of 8')
    } else if (!password.match(numbers)) {
      alert('please add 1 number')
    } else if (!password.match(upperCaseLetters)) {
      alert('please add 1 uppercase letter')
    } else if (!password.match(lowerCaseLetters)) {
      alert('please add 1 lovercase letter')
    } else {
      localStorage.setItem('name', JSON.stringify(name))
      localStorage.setItem('password', JSON.stringify(password))

      alert('registered successfully')
    }
  }

  render() {
    const {name, email, phone, password, err} = this.state
    return (
      <div className="signup-container">
        <h1 className="heading">Registration</h1>
        <form className="form" onSubmit={this.onSubmit}>
          <div className="form-group">
            <label htmlFor="name" className="label1">
              Name
            </label>
            <br />
            <input
              type="text"
              className="form-control"
              value={name}
              onChange={this.onChangeName}
              id="name"
              required
            />
            <p>{err}</p>
          </div>
          <br />
          <div className="form-group">
            <label htmlFor="email" className="label1">
              Email
            </label>
            <br />
            <input
              type="email"
              className="form-control"
              value={email}
              onChange={this.onChangeEmail}
              id="email"
              required
            />
          </div>
          <br />
          <div className="form-group">
            <label htmlFor="phone" className="label1">
              Phone
            </label>
            <br />
            <input
              type="number"
              className="form-control"
              value={phone}
              id="phone"
              onChange={this.onChangePhone}
              required
            />
          </div>
          <br />
          <div className="form-group">
            <label htmlFor="password" className="label1">
              Password
            </label>
            <br />
            <input
              type="password"
              className="form-control"
              value={password}
              id="password"
              onChange={this.onChangePassword}
              required
            />
          </div>
          <br />
          <button type="submit" className="btn button1 btn-primary btn-block">
            Register
          </button>
          <Link to="/login">
            <p className="login">Login</p>
          </Link>
        </form>
      </div>
    )
  }
}

export default Register
