const data = {
  currencies: [
    {
      code: 'AUD',
      sellRate: 1,
      name: 'Australian Dollars',
      sign: '$',
    },
    {
      code: 'INR',
      sellRate: 73.71,
      name: 'Indian Rupee',
      sign: '₹',
    },
    {
      code: 'CAD',
      sellRate: 0.9504,
      name: 'Canadian Dollars',
      sign: '$',
    },
    {
      code: 'NZD',
      sellRate: 0.9949,
      name: 'New Zealand Dollars',
      sign: '$',
    },
    {
      code: 'JPY',
      sellRate: 78.21,
      name: 'Japanese Yen',
      sign: '¥',
    },
    {
      code: 'GBP',
      sellRate: 0.5472,
      name: 'British Pounds Sterling',
      sign: '£',
    },
    {
      code: 'AUD',
      sellRate: 0.7041,
      name: 'United States Dollars',
      sign: '$',
    },
  ],
}

export default data
