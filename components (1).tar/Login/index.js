import React from 'react'

import {FcGoogle} from 'react-icons/fc'

import {Redirect, Link} from 'react-router-dom'

import './index.css'

class Login extends React.Component {
  state = {
    name: '',
    email: '',
    phone: '',
    password: '',
    err: '',
  }

  onChangeName = e => {
    this.setState({name: e.target.value})
  }

  onChangeEmail = e => {
    this.setState({email: e.target.value})
  }

  onChangePhone = e => {
    this.setState({phone: e.target.value})
  }

  onSubmit = e => {
    e.preventDefault()
    // const {name, password} = this.props

    const {history} = this.props
    const {name, password} = this.state
    const storedName = localStorage.getItem('name')
    // console.log(typeof storedName)

    const storedPw = localStorage.getItem('password')
    // console.log(typeof storedPw)
    // console.log(typeof name)
    // console.log(typeof password)

    // const userName = document.getElementById('userName')
    // const userPw = document.getElementById('userPw')
    // const userRemember = document.getElementById('rememberMe')

    if (storedName === name && storedPw === password) {
      alert('login')
    } else {
      alert('login successfully')

      history.replace('/')
    }
  }

  onChangePassword = e => {
    this.setState({password: e.target.value})
  }

  render() {
    const {name, email, phone, password, err} = this.state
    return (
      <div className="login-container">
        <h1 className="heading">Login Page</h1>
        <div className="container">
          <form onSubmit={this.onSubmit}>
            <p className="error">{err}</p>
            <div className="form-group">
              <label htmlFor="name" className="label">
                Name
              </label>

              <br />
              <input
                type="text"
                className="form-control"
                value={name}
                id="name"
                onChange={this.onChangeName}
                required
              />
            </div>
            <br />

            <label htmlFor="password" className="label">
              Password
            </label>
            <br />
            <input
              type="password"
              className="form-control"
              id="password"
              value={password}
              onChange={this.onChangePassword}
              required
            />

            <br />
            <button type="submit" className="btn button btn-primary btn-block">
              Login
            </button>

            <Link className="signup" to="./signup">
              Signup
            </Link>
            <Link className="signup2" to="./forgot">
              Forgot
            </Link>
            <Link className="signup3" to="./Google">
              <FcGoogle />
            </Link>
          </form>
        </div>
      </div>
    )
  }
}

export default Login
