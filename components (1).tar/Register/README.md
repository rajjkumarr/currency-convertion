working of website:

In the home page.currency converter is there we can convert the currencies using this website

=>logout:when we click on the logout button all the stored data in the local storage will be remove and navigate to login route

=>login:we can login using the username,password if username,password doesn't match we have forgot page

=>Forgot:we can reset password using forgot route

=>Google:we can also login using Google account

=>Register:if we want create a account simply we can click on register name,it will navigate register page.

in the register page we can store data like name,password, username,email,phone using the localStorage.

if we click on the login .it will navigate to login page.
