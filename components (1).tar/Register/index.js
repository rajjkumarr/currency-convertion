import React, {Component} from 'react'
import {Link} from 'react-router-dom'
import {Nav, Navbar, NavItem} from 'react-bootstrap'
// import {LinkContainer} from 'react-router-bootstrap'

import './index.css'

class Register extends Component {
  render() {
    return (
      <div className="App container">
        <Nav>
          <Link to="/signup" className="btn btn-primary btn-block">
            <NavItem>Register</NavItem>
          </Link>
          <br />
          <Link to="/login" className="btn btn-primary btn-block">
            <NavItem>Login</NavItem>
          </Link>
        </Nav>
      </div>
    )
  }
}
export default Register
